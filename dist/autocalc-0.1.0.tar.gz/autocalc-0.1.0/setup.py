# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

modules = \
['autocalc']
setup_kwargs = {
    'name': 'autocalc',
    'version': '0.1.0',
    'description': 'Avtomatize DPD calculations',
    'long_description': '',
    'author': 'Ivan Mikhailov, Pavel Semishin, Serafim',
    'author_email': 'mikhailov.ivan@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'py_modules': modules,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
